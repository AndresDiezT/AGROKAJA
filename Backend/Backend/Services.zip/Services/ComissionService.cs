﻿using Backend.DTOs;
using Backend.Interfaces;
using Backend.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;


namespace Backend.Services
{
    public class ComissionService : IComissionService
    {

        private readonly Data.BackendDbContext _dbContext;

        public ComissionService(Data.BackendDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<Comission>> GetAllComissionsAsync()
        {
            var comissions = await _dbContext.Comissions.ToListAsync();

            return comissions;
        }
        public async Task<Comission> GetComissionByIdAsync(int id)
        {
            var comission = await _dbContext.Comissions
                .FirstOrDefaultAsync(c => c.IdComission == id); ;
            if (comission is null)
            {
                return¿("Comision no encontrada");
            }
        }

        public Task<Comission> CreateComissionAsync(Comission comission)
        {
            throw new NotImplementedException();
        }
        public Task<Comission> UpdateComissionAsync(Comission comission)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeactivateComissionAsync(int id)
        {
            throw new NotImplementedException();
        }
       
        public Task<bool> ActivateComissionAsync(int id)
        {
            throw new NotImplementedException();
        }

       
    }
}
