﻿using Backend.DTOs.AddressDTOs;
using Backend.DTOs;
using Backend.Models;

namespace Backend.Interfaces
{
    public interface IComissionService
    {
        Task<IEnumerable<Comission>> GetAllComissionsAsync();
        Task<Comission> GetComissionByIdAsync(int id);
        Task<Comission> CreateComissionAsync(Comission comission);
        Task<Comission> UpdateComissionAsync(Comission comission);
        Task<bool> DeactivateComissionAsync(int id);
        Task<bool> ActivateComissionAsync(int id);
    }
}
